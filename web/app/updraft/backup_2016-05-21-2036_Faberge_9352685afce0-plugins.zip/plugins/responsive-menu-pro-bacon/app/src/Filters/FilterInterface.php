<?php

interface ResponsiveMenuPro_Filters_FilterInterface {
	public function apply();
}
